<p align="center">
<a href="https://misyaz-pelitari.github.io/"><img title="Made in Malaysia" src="https://img.shields.io/badge/MADE%20IN-MALAYSIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://misyaz-pelitari.github.io/"><img title="Made in MALAYSIA" src="https://img.shields.io/badge/Tool-TermuxOs-green.svg"></a>
<a href="https://misyaz-pelitari.github.io/"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://misyaz-pelitari.github.io/"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>
<p align="center">
 <a href=""><img src="img/6.jpg" width="800" hight="400"></a>
</p>
<p align="center">
<a href="https://github.com/misyaz-pelitari"><img title="Github" src="https://img.shields.io/badge/misyaz-pelitari-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://youtu.be/Gongperai"><img title="YouTube" src="https://img.shields.io/badge/YouTube-H4CK3R-red?style=for-the-badge&logo=Youtube"></a>
</p>


# Termux-os

Based on Zsh Shell

Pure Termux Look

Credits to Oh My Zsh

# Features

Added Termux Extra Keys

<p align="center">
  <img src="img/1.jpg" width="300" hight="220">
</p>

Added Banner 

<p align="center">
  <img src="img/4.jpg" width="300" hight="220">
</p>

Added Own made Advance zsh theme
<p align="center">
  <img src="img/2.jpg" width="300" hight="220">
</p>

Added Highlight / Autosuggestion

<p align="center">
  <img src="img/3.jpg" width="300" hight="220">
</p>

# Photos Of Theme




<p align="center">
  <img src="img/5.jpg" width="300" hight="220">
</p>

# Installation



git clone https://github.com/misyaz-pelitari/Termux-os

cd Termux-os

bash os.sh
